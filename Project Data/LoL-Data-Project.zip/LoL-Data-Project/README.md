# LoL-Data-Project
A data science project looking at data collected across 50,000+ games from League of Legends.
